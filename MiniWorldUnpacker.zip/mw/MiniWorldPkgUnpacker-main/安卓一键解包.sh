#!/data/data/com.termux/files/usr/bin/bash
# ==========================================================
#  迷你世界 .pkg 解包 —— 安卓 Termux 一键脚本
#  用法：把本文件放进 Termux 家目录，执行：
#        bash 安卓一键解包.sh /sdcard/你的目录/common_res.pkg
#  产物：当前目录 unpack/
# ==========================================================
set -e
PKG="$1"
HERE="$(cd "$(dirname "$0")" && pwd)"

if [ -z "$PKG" ]; then
  echo "用法: bash 安卓一键解包.sh <pkg文件路径>"
  echo ""
  echo "常见位置（迷你世界装在手机里时）:"
  echo "  /sdcard/Android/data/com.playmini.miniworld/files/..."
  echo "  /sdcard/Android/obb/com.playmini.miniworld/..."
  exit 1
fi
[ -f "$PKG" ] || { echo "❌ 找不到文件: $PKG"; exit 1; }

echo "[1/4] 安装依赖..."
pkg install -y python python-pip >/dev/null 2>&1 || true
python3 -c "import lz4" 2>/dev/null || pip install lz4 pillow -q
echo "      ✅ 依赖就绪"

echo "[2/4] 准备 ARM64 解码器..."
chmod +x "$HERE/tools/crn2rgba_linux_arm64"
mkdir -p "$HERE/tools"
cp -f "$HERE/tools/crn2rgba_linux_arm64" "$HERE/tools/crn2rgba" 2>/dev/null || true
chmod +x "$HERE/tools/crn2rgba"
echo "      ✅ $(file "$HERE/tools/crn2rgba" | cut -c1-60)"

echo "[3/4] 解包中（大包可能要几分钟）..."
cd "$HERE"
python3 UnpackAll.py "$PKG"

echo "[4/4] 完成！"
echo "      产物目录: $HERE/unpack/"
find "$HERE/unpack" -name "*.png" 2>/dev/null | wc -l | xargs echo "      贴图 PNG 数量:"
